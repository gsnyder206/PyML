PyML
=======================

A machine learning set of tools for using PCA to classify galaxies using agglomerative clustering and convex hulls.