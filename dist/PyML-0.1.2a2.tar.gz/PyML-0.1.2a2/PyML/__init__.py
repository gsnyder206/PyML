__version__ = "0.1"
__author__ = "Michael Peth, JHU"
from convexhullclassifier import *
from machinelearning import *